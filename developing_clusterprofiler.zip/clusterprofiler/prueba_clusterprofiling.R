BiocManager::install("org.At.tair.db", version = "3.8")
BiocManager::install("topGO", version = "3.8")
BiocManager::install("Rgraphviz", version = "3.8")
BiocManager::install("Rgraphviz", version = "3.8")


library("org.At.tair.db")
keytypes(org.At.tair.db)
library("clusterProfiler")
library("topGO")
library("Rgraphviz")

#You may have installed clusterProfiler, topGO and the organism's database packages 
#before starting the analysis

#Read the query gene list. 
gene.list<-read.table(file = "target_genes.txt",header = F,sep = "")

#is it a vector parameter? 
is.vector(gene.list)

#If not, use as.vector to swich it into a vector-like parameter.
cool.genes<-as.vector(gene.list[,1])
is.vector(cool.genes)
head(cool.genes)

#Read the list of genes that you will use as a background (your own or the one given by the user)
#Repeat the proccess to make it work as a vector. 
genes.background<-as.vector(read.table(file = "All_genes_athalina.txt", header = F, sep = ""))
is.vector(genes.background)
cool.background<-as.vector(genes.background[,1])
is.vector(cool.background)
head(cool.background)


#With enrichGO you will make the GO enrichment analysis.  
ego <- enrichGO(gene          = cool.genes,
                universe      = cool.background,
                OrgDb         = org.At.tair.db,
                ont           = "MF",
                pAdjustMethod = "BH",
                pvalueCutoff  = 0.01,
                qvalueCutoff  = 0.05,
                readable      = F,
                keyType = "TAIR")
#�ojo cuidao!, No poner readable=T porque se usa el paquete DOSE para ello, y este traduce los
#genes desde ENTREZID a SYMBOL. Por lo tanto, te saldr�n errores porque solo aceptar� genes
#nombrados bajo la terminolog�a ENTREZID.
               
#Save the results GO enrichment.
head(as.data.frame(ego@result))
write.table(x = ego@result,file = "enrichGOresults.txt")

#Visualize the resuts and save them in a pdf file
pdf(file = "plotGO_MF.pdf")
plotGOgraph(ego)
dev.off()

####KEGG analysis (not available for D. salina )
#KEGG name for each of our green algae: 
#O. tauri->ota; O. lucimarinus->olu;
#B. prasinos-> bpg; M. pusilla->mpp;
#C. subellipsoidea ->csl; C. reinhardtii->cre

ekegg<-enrichKEGG(gene = cool.genes,
                  universe = cool.background, 
                  organism = "ath", 
                  pvalueCutoff = 0.01,
                  qvalueCutoff = 0.05, 
                  pAdjustMethod = "BH",
                  use_internal_data = F )
#Si dejamos que use los datos internos, usar� los datos del KEGG.db, los cuales son criticados
#por no estar debidamente actualizados. En su lugar, se descargar� la versi�n m�s actualizada
#de la red. 

#Save the results GO enrichment.
head(as.data.frame(ekegg@result))
write.table(x = ekegg@result,file = "enrichKEGGresults.txt")

#visualize the results. 
browseKEGG(x = ekegg,pathID = "all")

